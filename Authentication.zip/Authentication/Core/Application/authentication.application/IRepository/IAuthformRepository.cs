﻿using authentication.application.DTO;
using authentication.domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace authentication.application.IRepository
{
    public interface IAuthformRepository
    {
        Task<User?> regiseter(User user,string password,string role);
        Task<string> login(string email, string password);
        Task<string> createRole(string role);
        Task<IEnumerable<User>> getAll();
    }
}
